﻿namespace Framework.UI.TestHarness.Views
{
    /// <summary>
    /// Interaction logic for ThemeView.xaml
    /// </summary>
    public partial class ThemeView
    {
        public ThemeView()
        {
            InitializeComponent();
        }
    }
}
