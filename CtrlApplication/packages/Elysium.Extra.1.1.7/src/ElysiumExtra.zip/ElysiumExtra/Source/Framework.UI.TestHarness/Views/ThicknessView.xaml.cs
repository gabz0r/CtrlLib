﻿namespace Framework.UI.TestHarness.Views
{
    /// <summary>
    /// Interaction logic for ThicknessView.xaml
    /// </summary>
    public partial class ThicknessView
    {
        public ThicknessView()
        {
            InitializeComponent();
        }
    }
}
