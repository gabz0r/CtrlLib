﻿namespace Framework.UI.TestHarness.Views
{
    /// <summary>
    /// Interaction logic for TextView.xaml
    /// </summary>
    public partial class TextView
    {
        public TextView()
        {
            InitializeComponent();
        }
    }
}
